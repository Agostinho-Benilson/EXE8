package com.example.exe8_tic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private EditText salario_minimo;
    private EditText qtd_quilo;

    private Button btn_calcular;

    private TextView valor_cada;
    private TextView valor_a_ser_pago;
    private TextView valor_15;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        salario_minimo = findViewById(R.id.salario_minimo);
        qtd_quilo = findViewById(R.id.qtd_quilo);

        btn_calcular = findViewById(R.id.btn_calcular);

        valor_cada = findViewById(R.id.valor_cada);
        valor_a_ser_pago = findViewById(R.id.valor_a_ser_pago);
        valor_15 = findViewById(R.id.valor_15);

        btn_calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float salario = Float.parseFloat(salario_minimo.getText().toString());
                float qtd = Float.parseFloat(qtd_quilo.getText().toString());

                float custo = salario / 5;
                float valor_pago = custo * qtd;
                float valor_pago_15 = valor_pago - ((valor_pago * 15)/100);

                valor_cada.setText("O valor de cada Quilowatt: " + custo);
                valor_a_ser_pago.setText("Valor a ser pago: " + valor_pago);
                valor_15.setText("O valor com desconto de 15%: "+ valor_pago_15 );


            }
        });
    }
}